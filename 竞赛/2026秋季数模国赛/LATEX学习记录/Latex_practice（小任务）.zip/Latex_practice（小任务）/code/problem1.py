# simple math operation
a = 3
b = 5

if a < b:
    result = a + b
    print("result =", result)