module APB_Slave_Memory(
    input         clk,
    input         reset_n,

    input  [15:0] io_apbSlave_0_PADDR,
    input         io_apbSlave_0_PSEL,
    input         io_apbSlave_0_PENABLE,
    input         io_apbSlave_0_PWRITE,
    input  [31:0] io_apbSlave_0_PWDATA,

    output        io_apbSlave_0_PREADY,
    output   [31:0] io_apbSlave_0_PRDATA,
    output        io_apbSlave_0_PSLVERROR
);

// APB3 状态
localparam IDLE   = 2'b00;
localparam SETUP  = 2'b01;
localparam ACCESS = 2'b10;

reg [1:0] current_state;
reg [1:0] next_state;

reg slaveReady;
// 状态机时序逻辑
always @(posedge clk or negedge reset_n) begin
    if(!reset_n)
        current_state <= IDLE;
    else
        current_state <= next_state;
end

// 组合逻辑：状态跳转（正确！）
always @(*) begin
    next_state = IDLE;
    case(current_state)
        IDLE: begin
            if(io_apbSlave_0_PSEL&&!io_apbSlave_0_PENABLE)
                next_state = SETUP;
            else
                next_state = IDLE;
        end
        SETUP: begin
            if(io_apbSlave_0_PSEL&&io_apbSlave_0_PENABLE)
                next_state = ACCESS;
            else
                next_state=IDLE;
        end
        ACCESS:
        if(io_apbSlave_0_PREADY)
            next_state=IDLE;
        else
            next_state=ACCESS;
        default:begin
            next_state=IDLE;
        end
    endcase
end
// 错误信号
assign io_apbSlave_0_PSLVERROR = 1'b0;

// ✅ 正确写使能
wire write_en = io_apbSlave_0_PWRITE&(current_state==ACCESS);
wire read_en  = !io_apbSlave_0_PWRITE&(current_state == ACCESS);

assign io_apbSlave_0_PREADY = slaveReady && (current_state !== IDLE);

always@ (posedge clk)
begin
    slaveReady <= write_en |read_en;
end

bram_test bram_test_inst (
    .clk      (clk),
    .reset    (~reset_n),
    .we       (write_en),
    .waddr    (io_apbSlave_0_PADDR/4),
    .wdata_a  (io_apbSlave_0_PWDATA),
    .re       (read_en),
    .raddr    (io_apbSlave_0_PADDR/4),
    .rdata_b  (io_apbSlave_0_PRDATA)
);


endmodule