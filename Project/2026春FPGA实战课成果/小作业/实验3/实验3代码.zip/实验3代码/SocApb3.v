 module SocApb3
(
    input pll_inst1_CLKOUT0,
    input pll_inst1_LOCKED,

    input jtag_inst1_TDI,
    input jtag_inst1_TCK,
    input jtag_inst1_TMS,
    input jtag_inst1_SEL,
    input jtag_inst1_DRCK, 
    input jtag_inst1_RESET,
    input jtag_inst1_RUNTEST,
    input jtag_inst1_CAPTURE,
    input jtag_inst1_SHIFT,
    input jtag_inst1_UPDATE,   
    
    output jtag_inst1_TDO,

    input uart_rx,
    output uart_tx,

    output [7:0] led_data
);

wire [15:0] apb_paddr;
wire        apb_psel;
wire        apb_penable;
wire        apb_pwrite;
wire [31:0] apb_pwdata;
wire        apb_pready;
wire [31:0] apb_prdata;
wire        apb_pslverr;

wire clk = pll_inst1_CLKOUT0;

reg rst_n = 1'b0;
reg [3:0] rst_cnt = 4'd0;

always @(posedge clk) begin
    if (rst_cnt < 4'd15) begin
        rst_cnt <= rst_cnt + 1'd1;
        rst_n   <= 1'b0;  // 复位中
    end else begin
        rst_n   <= 1'b1;  // 释放复位
    end
end

soc_test soc_test_inst
(
    .io_systemClk               (clk),
    .io_asyncReset              (~rst_n),

    .jtagCtrl_enable            (jtag_inst1_SEL),
    .jtagCtrl_tdi               (jtag_inst1_TDI),
    .jtagCtrl_tck               (jtag_inst1_TCK),
    .jtagCtrl_tdo               (jtag_inst1_TDO),
    .jtagCtrl_capture            (jtag_inst1_CAPTURE),
    .jtagCtrl_reset               (jtag_inst1_RESET),
    .jtagCtrl_shift               (jtag_inst1_SHIFT),
    .jtagCtrl_update               (jtag_inst1_UPDATE),


    .system_uart_0_io_txd       (uart_tx ),
    .system_uart_0_io_rxd       (uart_rx ),

    .io_apbSlave_0_PADDR        (apb_paddr),
    .io_apbSlave_0_PSEL         (apb_psel),
    .io_apbSlave_0_PENABLE      (apb_penable),
    .io_apbSlave_0_PWRITE       (apb_pwrite),
    .io_apbSlave_0_PWDATA       (apb_pwdata),
    .io_apbSlave_0_PREADY       (apb_pready),
    .io_apbSlave_0_PRDATA       (apb_prdata),
    .io_apbSlave_0_PSLVERROR    (apb_pslverr)
);

// 例化 APB 从机
APB_Slave_Memory APB_Slave_Memory_inst (
    .clk                        (clk),
    .reset_n                    (rst_n),

    .io_apbSlave_0_PADDR        (apb_paddr),
    .io_apbSlave_0_PSEL         (apb_psel),
    .io_apbSlave_0_PENABLE      (apb_penable),
    .io_apbSlave_0_PWRITE       (apb_pwrite),
    .io_apbSlave_0_PWDATA       (apb_pwdata),
    .io_apbSlave_0_PREADY       (apb_pready),
    .io_apbSlave_0_PRDATA       (apb_prdata),
    .io_apbSlave_0_PSLVERROR    (apb_pslverr)
);

assign led_data = apb_prdata[7:0];

endmodule