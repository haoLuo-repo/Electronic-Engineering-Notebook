void main() {
    struct ctrl_reg cfg0={0};
    u32 w_data = 0;
    u32 r_data=0;

    bsp_init();

#ifdef IO_APB_SLAVE_0_INPUT

    bsp_printf("apb3 slave 0 demo ! \r\n");
    cfg0.lfsr_stop=1;
    apb3_ctrl_write(APB0,&cfg0);
    r_data = read_u32(APB0+EXAMPLE_APB3_SLV_REG1_OFFSET);
    bsp_printf("Random number: 0x%x \r\n", r_data);
    if(r_data == 0x0)
        error_state();
    else
        bsp_printf("Passed! \r\n");

    bsp_printf("\r\n APB3 读写测试开始\r\n");

        #define DELAY for(volatile int i=0; i<4000000; i++);
    // 1. 写 0x55 → 读回
        w_data = 0x55;
        cfg_data(APB0, w_data);
        r_data = read_u32(APB0+EXAMPLE_APB3_SLV_REG4_OFFSET);
        bsp_printf("写: 0x%02X  | 读: 0x%02X\r\n", w_data, r_data);
        DELAY;

        // 2. 写 0xAA → 读回
        w_data = 0xAA;
        cfg_data(APB0, w_data);
        r_data = read_u32(APB0+EXAMPLE_APB3_SLV_REG4_OFFSET);
        bsp_printf("写: 0x%02X  | 读: 0x%02X\r\n", w_data, r_data);
        DELAY;

        // 3. 写 0x0F → 读回
        w_data = 0x0F;
        cfg_data(APB0, w_data);
        r_data = read_u32(APB0+EXAMPLE_APB3_SLV_REG4_OFFSET);
        bsp_printf("写: 0x%02X  | 读: 0x%02X\r\n", w_data, r_data);
        DELAY;

        // 4. 写 0xF0 → 读回
        w_data = 0xF0;
        cfg_data(APB0, w_data);
        r_data = read_u32(APB0+EXAMPLE_APB3_SLV_REG4_OFFSET);
        bsp_printf("写: 0x%02X  | 读: 0x%02X\r\n", w_data, r_data);
        DELAY;

        bsp_printf("\r\n=== APB3 测试完成 ===\r\n");


#else

    bsp_printf("apb3 Slave 0 is disabled, please enable it to run this app. \r\n");

#endif